// src/components/Home.tsx
import React from 'react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-50% bg-center bg-no-repeat bg-hero-image">
      <div className="bg-gray-900 bg-opacity-75 p-8 rounded-lg text-white">
        <h1 className="text-4xl font-bold mb-8">Welcome to Your Application</h1>
        <div className="space-y-4">
          <Link to="/GeneralContact">
            <button className="bg-blue-500 hover:bg-blue-600 text-white mx-2 py-2 px-4 rounded">
              Go to General Contact
            </button>
          </Link>
          <Link to="/ServiceRequest">
            <button className="bg-green-500 hover:bg-green-600 text-white mx-2 py-2 px-4 rounded">
              Go to Service Request
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;
